export function IncrementCourseLikes(){ // action creator
    return {type:'INCREMENT_LIKES'}; // action
}

export function DeleteCourse(){ // action creator
    return {type:'DELETE_COURSE'}; // action
}


export function DeletePost(){ // action creator
    return {type:'DELETE_POST'}; // action
}