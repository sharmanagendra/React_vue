export function posts(defStore=[],action){
    console.log('Within posts Reducer');
    return defStore; // return a new store data
}