export function courses(defStore=[],action){
    console.log('Within Course Reducer');
    return defStore; // return a new store data
}