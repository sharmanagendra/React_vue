<template>
<listofcourses></listofcourses>
</template>

<script>
import listofcourses from './components/listofcourses.component';

export default {
    name: 'app',
    components: {
        listofcourses
    }
}
</script>

<style>

</style>
